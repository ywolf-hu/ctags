These source files were taken from the GNU glibc-2.10.1 package.

    ftp://ftp.gnu.org/gnu/glibc/glibc-2.10.1.tar.bz2

Minor changes were made to eliminate compiler errors and warnings.
