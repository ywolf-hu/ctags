// =====================================================================================
//
//       Filename:  Ttcn3.c
//
//    Description:  
//
//        Version:  1.0
//        Created:  2015年02月16日 19时44分29秒
//       Revision:  none
//       Compiler:  g++
//
//         Author:  ywolf (), hlf0312@gmail.com
//   Organization:  
//
// =====================================================================================

#include "general.h"        /* must always come first */

#include <string.h>
#include <setjmp.h>

#include "debug.h"
#include "entry.h"
#include "get.h"
#include "keyword.h"
#include "options.h"
#include "parse.h"
#include "read.h"
#include "routines.h"
typedef enum eTtcn3Kinds {
    K_DEFINE
} ttcn3Kind;

static kindOption Ttcn3Kinds [] = {
    { TRUE, 'm', "module", "module definition" }
};

/* FUNCTION DEFINITIONS */
/*
static void findTtcn3Tags (void)
{
    vString *name = vStringNew ();
    const unsigned char *line;
   printf("findttcn3tags\n");
    while ((line = fileReadLine ()) != NULL)
    {
        if (strncmp ((const char*) line, "module", (size_t) 6) == 0  &&
                isspace ((int) line [6]))
        {
            const unsigned char *cp = line + 7;
            while (isspace ((int) *cp))
                ++cp;
            while (isalnum ((int) *cp)  ||  *cp == '_')
            {
                vStringPut (name, (int) *cp);
                ++cp;
            }
            printf("%s\n", name->buffer);
            vStringTerminate (name);
            makeSimpleTag (name, Ttcn3Kinds, K_DEFINE);
            vStringClear (name);
        }
    }
    vStringDelete (name);
}

extern parserDefinition* Ttcn3Parser (void)
{
    static const char *const extensions [] = { "ttcn3", NULL };
    parserDefinition* def = parserNew ("Ttcn3");
    def->kinds      = Ttcn3Kinds;
    def->kindCount  = KIND_COUNT (Ttcn3Kinds);
    def->extensions = extensions;
    def->parser     = findTtcn3Tags;
    return def;
}
*/

static void installTtcn3Regex (const langType language)
{
    addTagRegex (language, "^[ \t]*module[ \t]+([A-Za-z][A-Za-z0-9_]*)([^A-Za-z0-9_]|$)", "\\1", "m, module definition", NULL);
    addTagRegex (language, "^[ \t]*(external[ \t]+)?function[ \t]+([A-Za-z][A-Za-z0-9_]*)([^A-Za-z0-9_]|$)", "\\2", "f, function definition", NULL);
    addTagRegex (language, "^[ \t]*altstep[ \t]+([A-Za-z][A-Za-z0-9_]*)([^A-Za-z0-9_]|$)", "\\1", "a,altstep definitions", NULL);
    addTagRegex (language, "^[ \t]*testcase[ \t]+([A-Za-z][A-Za-z0-9_]*)([^A-Za-z0-9_]|$)", "\\1", "x,test case definitions", NULL);
    addTagRegex (language, "^[ \t]*const[ \t]+([A-Za-z][A-Za-z0-9_]*.)*[A-Za-z][A-Za-z0-9_]*[ \t]+([A-Za-z][A-Za-z0-9_]*)([^A-Za-z0-9_]|$)", "\\2", "c,const definitions", NULL);
    addTagRegex (language, "^[ \t]*template[ \t]+([A-Za-z][A-Za-z0-9_]*.)*[A-Za-z][A-Za-z0-9_]*[ \t]+([A-Za-z][A-Za-z0-9_]*)[ \t]*([^A-Za-z0-9_]|$)", "\\2", "r,template definitions", NULL);
    addTagRegex (language, "^[ \t]*type[ \t]+record[ \t]+length[ \t]+\\([^)]+\\)[ \t]*of[ \t]+[A-Za-z][A-Za-z0-9_]*[ \t]+([A-Za-z][A-Za-z0-9_]*)", "\\1", "t,type definitions", NULL);
    addTagRegex (language, "^[ \t]*type[ \t]+record[ \t]+([A-Za-z][A-Za-z0-9_]*)", "\\1", "t,type definitions", NULL);
    addTagRegex (language, "^[ \t]*type[ \t]+set[ \t]+of[ \t]+[A-Za-z][A-Za-z0-9_]*[ \t]+([A-Za-z][A-Za-z0-9_]*)", "\\1", "t,type definitions", NULL);
    addTagRegex (language, "^[ \t]*type[ \t]+enumerated[ \t]+([A-Za-z][A-Za-z0-9_]*)", "\\1", "t,type definitions", NULL);
    addTagRegex (language, "^[ \t]*type[ \t]+u[0-9]+[ \t]+([A-Za-z][A-Za-z0-9_]*)", "\\1", "t,type definitions", NULL);
    addTagRegex (language, "^[ \t]*template[ \t]+[A-Za-z][A-Za-z0-9_]*[ \t]+([A-Za-z][A-Za-z0-9_]*)", "\\1", "r,template definitions", NULL);
    addTagRegex (language, "^[ \t]*type[ \t]+union[ \t]+([A-Za-z][A-Za-z0-9_]*)", "\\1", "t,type definitions", NULL);
}

extern parserDefinition* Ttcn3Parser (void)
{
    static const char *const extensions [] = { "ttcn3", NULL };
    parserDefinition* def = parserNew ("Ttcn3");
    def->extensions = extensions;
    def->initialize = installTtcn3Regex;
    def->regex      = TRUE;
    return def;
}

